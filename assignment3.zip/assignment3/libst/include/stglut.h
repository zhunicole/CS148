// stglut.h
#ifndef __STGLUT_H__
#define __STGLUT_H__

#include "stgl.h"

//
// The path to the glut header file may differ on
// your system. Change it if needed.
//
#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#endif // __STGLUT_H__
