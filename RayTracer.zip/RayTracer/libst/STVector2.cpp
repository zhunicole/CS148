// STVector2.cpp
#include "STVector2.h"

//

const STVector2 STVector2::Zero(0.0f, 0.0f);
const STVector2 STVector2::eX(1.0f, 0.0f);
const STVector2 STVector2::eY(0.0f, 1.0f);
